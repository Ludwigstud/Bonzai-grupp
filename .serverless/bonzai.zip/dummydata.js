// data.js
// This script inserts dummy data into your DynamoDB table.
// The '#total' summary rows have been updated with 'totalGuests' and 'totalRooms'.

// 1. Import necessary clients from AWS SDK v3
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, BatchWriteCommand } from "@aws-sdk/lib-dynamodb";

// 2. Configure the client
const client = new DynamoDBClient({ region: "eu-north-1" }); // Ensure this is your AWS region
const docClient = DynamoDBDocumentClient.from(client);

// The name of your DynamoDB table
const tableName = "bonzai";

// 3. The dummy data with updated total rows
const dummyData = [
	{
		pk: "booking",
		sk: "room#S12512#billy#1",
		cost: 1000,
		startDate: "2025-09-22",
		endDate: "2025-09-25",
		name: "Billy Bryson",
		email: "billy@domain.com",
		people: 2,
		roomType: 2,
	},
	{
		pk: "booking",
		sk: "room#S12512#billy#2",
		cost: 1500,
		startDate: "2025-09-22",
		endDate: "2025-09-25",
		name: "Billy Bryson",
		email: "billy@domain.com",
		people: 1,
		roomType: 3,
	},
	{
		pk: "booking",
		sk: "room#S12512#billy#total",
		cost: 2500,
		startDate: "2025-09-22",
		endDate: "2025-09-25",
		name: "Billy Bryson",
		email: "billy@domain.com",
		totalGuests: 3, // UPDATED from 'people'
		totalRooms: 2, // UPDATED from 'roomType'
	},
	{
		pk: "booking",
		sk: "room#K98765#anna#1",
		cost: 1500,
		startDate: "2025-10-10",
		endDate: "2025-10-12",
		name: "Anna Andersson",
		email: "anna@example.se",
		people: 3,
		roomType: 3,
	},
	{
		pk: "booking",
		sk: "room#K98765#anna#total",
		cost: 1500,
		startDate: "2025-10-10",
		endDate: "2025-10-12",
		name: "Anna Andersson",
		email: "anna@example.se",
		totalGuests: 3, // UPDATED from 'people'
		totalRooms: 1, // UPDATED from 'roomType'
	},
	{
		pk: "booking",
		sk: "room#M44556#charlie#1",
		cost: 500,
		startDate: "2025-11-21",
		endDate: "2025-11-23",
		name: "Charlie Clark",
		email: "c.clark@workplace.com",
		people: 1,
		roomType: 1,
	},
	{
		pk: "booking",
		sk: "room#M44556#charlie#2",
		cost: 1000,
		startDate: "2025-11-21",
		endDate: "2025-11-23",
		name: "Charlie Clark",
		email: "c.clark@workplace.com",
		people: 2,
		roomType: 2,
	},
	{
		pk: "booking",
		sk: "room#M44556#charlie#total",
		cost: 1500,
		startDate: "2025-11-21",
		endDate: "2025-11-23",
		name: "Charlie Clark",
		email: "c.clark@workplace.com",
		totalGuests: 3, // UPDATED from 'people'
		totalRooms: 2, // UPDATED from 'roomType'
	},
];

// 4. Main function to perform the batch write operation
const seedDatabase = async () => {
	console.log(`Seeding database table: ${tableName}...`);

	const putRequests = dummyData.map((item) => ({
		PutRequest: {
			Item: item,
		},
	}));

	const command = new BatchWriteCommand({
		RequestItems: {
			[tableName]: putRequests,
		},
	});

	try {
		await docClient.send(command);
		console.log(
			`✅ Success: ${dummyData.length} items have been added to the '${tableName}' table.`,
		);
	} catch (error) {
		console.error("❌ Error seeding database:", error);
	}
};

// 5. Run the seeding function
seedDatabase();
